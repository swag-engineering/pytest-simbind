from .BaseModel import BaseModel


class Input:
    @property
    def EngineRPM(self) -> float:
        return float(0)

    @EngineRPM.setter
    def EngineRPM(self, value: float):
        pass
    
    @property
    def Gear(self) -> float:
        return float(0)

    @Gear.setter
    def Gear(self, value: float):
        pass
    
    @property
    def TransmissionRPM(self) -> float:
        return float(0)

    @TransmissionRPM.setter
    def TransmissionRPM(self, value: float):
        pass
    

class Output:
    @property
    def Ti(self) -> float:
        return float(0)
    
    @property
    def Tout(self) -> float:
        return float(0)
    

class Model(BaseModel):
    def __init__(self):
        self._time = 0
        self._time_step = 0.001
        self._input = Input()
        self._output = Output()
        self.initialize()

    @property
    def input(self) -> Input:
        """
        Input interface of the model. Available properties:
            EngineRPM: float
            Gear: float
            TransmissionRPM: float
        """
        return self._input

    @property
    def output(self) -> Output:
        """
        Output interface of the model. Available properties:
            Ti: float
            Tout: float
        """
        return self._output

    @property
    def time(self) -> float:
        return self._time

    def initialize(self) -> None:
        pass

    def step(self) -> None:
        self._time += self._time_step

    def terminate(self) -> None:
        pass
