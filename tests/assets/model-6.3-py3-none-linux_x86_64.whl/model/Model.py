from functools import wraps

from .BaseModel import BaseModel
from . import SimulinkModel


def collect(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if self.collector_callback:
            in_data = {
                "EngineRPM": self.input.EngineRPM,
                "Gear": self.input.Gear,
                "TransmissionRPM": self.input.TransmissionRPM
            }
            out_data = {
                "Ti": self.output.Ti,
                "Tout": self.output.Tout
            }
            self.collector_callback(self.time, in_data, out_data)
        return func(self, *args, **kwargs)
    return wrapper

class Input:
    @property
    def EngineRPM(self) -> float:
        return SimulinkModel.cvar.SimulinkModel_U.EngineRPM

    @EngineRPM.setter
    def EngineRPM(self, value: float):
        SimulinkModel.cvar.SimulinkModel_U.EngineRPM = value
    
    @property
    def Gear(self) -> float:
        return SimulinkModel.cvar.SimulinkModel_U.Gear

    @Gear.setter
    def Gear(self, value: float):
        SimulinkModel.cvar.SimulinkModel_U.Gear = value
    
    @property
    def TransmissionRPM(self) -> float:
        return SimulinkModel.cvar.SimulinkModel_U.TransmissionRPM

    @TransmissionRPM.setter
    def TransmissionRPM(self, value: float):
        SimulinkModel.cvar.SimulinkModel_U.TransmissionRPM = value
    

class Output:
    @property
    def Ti(self) -> float:
        return SimulinkModel.cvar.SimulinkModel_Y.Ti
    
    @property
    def Tout(self) -> float:
        return SimulinkModel.cvar.SimulinkModel_Y.Tout
    

class Model(BaseModel):
    def __init__(self, collector_callback=None):
        self.collector_callback = collector_callback
        self._input = Input()
        self._output = Output()
        self.initialize()

    @property
    def input(self) -> Input:
        """
        Input interface of the model. Available properties:
            EngineRPM: float
            Gear: float
            TransmissionRPM: float
        """
        return self._input

    @property
    def output(self) -> Output:
        """
        Output interface of the model. Available properties:
            Ti: float
            Tout: float
        """
        return self._output

    @property
    def _rt_model(self) -> SimulinkModel.tag_RTM_SimulinkModel_T:
        return SimulinkModel.cvar.SimulinkModel_M

    @property
    def time(self) -> float:
        return SimulinkModel.rtmGetT(self._rt_model)

    def initialize(self) -> None:
        return SimulinkModel.SimulinkModel_initialize()

    @collect
    def step(self) -> None:
        return SimulinkModel.SimulinkModel_step()

    @collect
    def terminate(self) -> None:
        return SimulinkModel.SimulinkModel_terminate()
